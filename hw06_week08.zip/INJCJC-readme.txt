INJCJC is the U.S. Initial Jobless Claims, seasonal adjusted, series obtained from Bloomberg.
Initial unemployment claims track the number of people who have filed jobless claims for the
first time during the specified period with the appropriate government labor office. This 
number represents an inflow of people receiving unemployment benefits.